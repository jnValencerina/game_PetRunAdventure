var Area = function (rect)
{
    return rect.width * rect.height;
};

module.exports = Area;
