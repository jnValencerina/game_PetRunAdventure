var Dot = function (pointA, pointB)
{
    return ((pointA.x * pointB.x) + (pointA.y * pointB.y));
};

module.exports = Dot;
